/*------------------------------------------------------------------------
#   Module  : �ü� - ȣ�� (CURR)
#   File	: py_2040_cm.c
------------------------------------------------------------------------*/

/*------------------------------------------------------------------------
	Header Files
------------------------------------------------------------------------*/
#include	"py_cm.h"

/*------------------------------------------------------------------------
	Global Variables
------------------------------------------------------------------------*/
extern int	Rows;
int			Sk, Curr_Arry, In_Arry, FO_Flag;
char		ItemCd[15];

/*------------------------------------------------------------------------
	Function Prototypes
------------------------------------------------------------------------*/
static void		Disp_Scr (void);
static void		Info_Sise (void);
static void		Disp_Sise (void);

/*----------------------------------------------------------------------*/
void	py_2040_cm (void)
/*----------------------------------------------------------------------*/
{
	int		job_end;

	job_end = 1;

	initscr ();
	newwin (Rows, 80, 0, 0);

	Sise_SHM ();
	Info_Sise ();

	Disp_Sise ();
	Disp_Msg ("Enter:Retry I:Info Q:Quit ��:Up ��:Down");
	keypad (stdscr, TRUE);

	while (job_end)
	{
		Disp_Msg ("Enter:Retry I:Info Q:Quit ��:Up ��:Down");
		mvcur (stdscr->_cury, stdscr->_curx, Rows - 1, 79);
		switch (getch ())
		{
			case	'i':
			case	'I':										/* Info	*/
				Info_Sise ();
				break;
			case 	KEY_ESC:
			case 	KEY_LEFT:
			case 	KEY_RIGHT:
			case	'1':
				job_end = 0;
				refresh ();
				endwin ();
				break;
			case	'q':
			case	'Q':										/* Quit	*/
				Exit_Process ();
			case	'\n':									/* Retry	*/
				Disp_Sise ();
				Disp_Msg ("Enter:Retry I:Info Q:Quit ��:Up ��:Down");
				break;
			case	KEY_UP:
				if (In_Arry >= 29 || In_Arry < 0)
					In_Arry = 0;
				else
					In_Arry += 1;

				Disp_Sise();
				Disp_Msg ("Enter:Retry I:Info Q:Quit ��:Up ��:Down");
				break;
			case	KEY_DOWN:
				if (In_Arry > 29 || In_Arry <= 0)
					In_Arry = 29;
				else
					In_Arry -= 1;

				Disp_Sise();
				Disp_Msg ("Enter:Retry I:Info Q:Quit ��:Up ��:Down");
				break;
			default:
				clear ();
				Disp_Scr ();
				Disp_Msg ("You entered wrong key.");
				sleep (1);
				Disp_Msg ("Enter:Retry I:Info Q:Quit ��:Up ��:Down");
				break;
		}
	}

	refresh ();
	endwin ();

	return;
}

/*----------------------------------------------------------------------*/
static void		Disp_Scr (void)
/*----------------------------------------------------------------------*/
{
	Disp_Title ();
	attron (A_BOLD);
	mvaddstr (0, 18, "[2040] �ü� - ���簡 (CURR)");
	attroff (A_BOLD);
	Draw_Line (1, 0, 79);
	mvaddstr (2, 0, "��ǰ   (1:���� 2:�ɼ� 3:ELW)    �����ڵ�");
	Draw_Underline (2, 5, 1);
	Draw_Underline (2, 41, 12);
	mvaddstr (3, 0, "����");
	Draw_Underline (3, 5, 3);

	mvaddstr (5, 0,
		"����ð� [          ]  ü��ð� [          ]");
	mvaddstr (6, 0,
		"�����ڵ�                  �ѱ۸�");
	mvaddstr (8, 0, "���Ѱ�     .      ���Ѱ�     .");
	mvaddstr (9, 0, "�ð�      .       ����    .         ����    .");
	mvaddstr (10, 0,
		"ü�����        ����ȣ������         �����ŷ����(õ��)");

	mvaddstr (12, 0, "���簡    .");
	mvaddstr (13, 0, "�ŵ�1�켱ȣ��    .        �ż�1�켱ȣ��    .");
	mvaddstr (14, 0, "�ŵ�2�켱ȣ��    .        �ż�2�켱ȣ��    .");
	mvaddstr (15, 0, "�ŵ�3�켱ȣ��    .        �ż�3�켱ȣ��    .");
	mvaddstr (16, 0, "�ŵ�4�켱ȣ��    .        �ż�4�켱ȣ��    .");
	mvaddstr (17, 0, "�ŵ�5�켱ȣ��    .        �ż�5�켱ȣ��    .");

	mvaddstr (19, 0, "�ŵ���ȣ������            �ż���ȣ������");
	mvaddstr (20, 0, "�ŵ�1�켱ȣ������         �ż�1�켱ȣ������");
	mvaddstr (21, 0, "�ŵ�2�켱ȣ������         �ż�2�켱ȣ������");
	mvaddstr (22, 0, "�ŵ�3�켱ȣ������         �ż�3�켱ȣ������");
	mvaddstr (23, 0, "�ŵ�4�켱ȣ������         �ż�4�켱ȣ������");
	mvaddstr (24, 0, "�ŵ�5�켱ȣ������         �ż�5�켱ȣ������");

	mvaddstr (26, 0, "�ŵ���ȣ���Ǽ�            �ż���ȣ���Ǽ�");
	mvaddstr (27, 0, "�ŵ�1�켱ȣ���Ǽ�         �ż�1�켱ȣ���Ǽ�");
	mvaddstr (28, 0, "�ŵ�2�켱ȣ���Ǽ�         �ż�2�켱ȣ���Ǽ�");
	mvaddstr (29, 0, "�ŵ�3�켱ȣ���Ǽ�         �ż�3�켱ȣ���Ǽ�");
	mvaddstr (30, 0, "�ŵ�4�켱ȣ���Ǽ�         �ż�4�켱ȣ���Ǽ�");
	mvaddstr (31, 0, "�ŵ�5�켱ȣ���Ǽ�         �ż�5�켱ȣ���Ǽ�");

	return;
}

/*----------------------------------------------------------------------*/
static void		Info_Sise (void)
/*----------------------------------------------------------------------*/
{
	int 	i, rt, mid, right, left, jy, gj;;
	char	buf[80];

	Clear_Lines (2, Rows - 2);
	Disp_Scr ();

	Disp_Msg ("<��ǰ����> �Է� (Esc:Cancel)");
	while (1)
	{
		memset (&buf, 0, sizeof buf);
		Draw_Underline (2, 5, 1);
		rt = Get_String (2, 5, 1, buf);
		if (rt == -1)											/* skip	*/
			Disp_Msg ("<��ǰ����> �Է� (Esc:Cancel)");
		else if (rt == -4)									/* Space	*/
			Disp_Msg ("You cannot input SPACE (Esc:Cancel)");
		else if (rt == 1)										/* Esc	*/
			return;
		else
		{
			attron (A_UNDERLINE);
			mvaddstr (2, 5, buf);
			attroff (A_UNDERLINE);

			if (strlen (buf) != 1 || (buf[0] != '1' && buf[0] != '2' && buf[0] != '3'))
			{
				Disp_Msg ("��ǰ���� ���� (Esc:Cancel)");
				continue;
			}

			FO_Flag = AtoIf (buf, 1);
			break;
		}
	}

	Disp_Msg ("<�����ڵ�> �Է� (Esc:Cancel)");
	while (1)
	{
		memset (&buf, 0, sizeof buf);
		if (FO_Flag == 3)
		{
			Draw_Underline (2, 41, 12);
			rt = Get_String (2, 41, 12, buf);
		}
		else
		{
			Draw_Underline (2, 41, 8);
			rt = Get_String (2, 41, 8, buf);
		}

		if (rt == -1)											/* skip	*/
			Disp_Msg ("<�����ڵ�> �Է� (Esc:Cancel)");
		else if (rt == -4)									/* Space	*/
			Disp_Msg ("You cannot input SPACE (Esc:Cancel)");
		else if (rt == 1)										/* Esc	*/
			return;
		else
		{
			attron (A_UNDERLINE);
			mvaddstr (2, 41, buf);
			attroff (A_UNDERLINE);

			if (FO_Flag == 1)									/* ����	*/
			{
				for (Sk = 0; Sk < AtoIf(Shm_Futures[0].Futures_A0.cnt, 5); Sk ++)
				{
					if (memcmp (buf, Shm_Futures[Sk].Futures_A0.item_code+3,
						sizeof (Shm_Futures[Sk].Futures_A0.item_code) - 4) == 0)
						break;
				}

				if (Sk == AtoIf(Shm_Futures[0].Futures_A0.cnt, 5))
				{
					Disp_Msg ("���� �����ڵ� ������ (Esc:Cancel)");
					continue;
				}

				memcpy (ItemCd, buf, 8);
			}													/* �ɼ�	*/
			else
			if (FO_Flag == 2)
			{
				for (Sk = 0; Sk < AtoIf(Shm_Options[0].Options_A0.cnt, 5); Sk ++)
				{
					if (memcmp (buf, Shm_Options[Sk].Options_A0.item_code+3,
						sizeof (Shm_Options[Sk].Options_A0.item_code) - 4) == 0)
						break;
				}

				if (Sk == AtoIf(Shm_Options[0].Options_A0.cnt, 5))
				{
					Disp_Msg ("�ɼ� �����ڵ� ������ (Esc:Cancel)");
					continue;
				}

				memcpy (ItemCd, buf, 8);
			}
			else												/* ELW	*/
			{
				/* ���� ã�� */
				if ((memcmp (Shm_Elw[Shm_Elw[0].total_elw_cnt-1].Elw_Master.stock_code,
							buf, 12) == -1)	||
					(memcmp (Shm_Elw[0].Elw_Master.stock_code, buf, 12) == 1))
				{
					Disp_Msg ("ELW_01 �����ڵ� ������ (Esc:Cancel)");
					continue;
				}
				else
				{
					i = jy = left = 0;
					right = Shm_Elw[0].total_elw_cnt - 1;

					while( left <= right )
					{
						mid = (left + right) / 2;

						if (memcmp (Shm_Elw[mid].Elw_A1.stock_code, buf, 12) == 0)
						{
							jy = 1;
							break;
						}
						/* 1 ������ ũ�� */
						else if (memcmp (Shm_Elw[mid].Elw_A1.stock_code, buf, 12) == 1)
							right = mid-1;
						else if (memcmp (Shm_Elw[mid].Elw_A1.stock_code, buf, 12) == -1)
							left = mid+1;
						else
						{
							Disp_Msg ("A0 Serch NotOk");
							continue;
						}
						i ++;
					}

					if (jy == 0)
					{
						Disp_Msg ("ELW_02 �����ڵ� ������ (Esc:Cancel)");
						continue;
					}

					Sk = mid;
				}

				memcpy (ItemCd, buf, 12);
			}

			break;
		}
	}

	Disp_Msg ("<����> �Է� (Esc:Cancel)");
	while (1)
	{
		memset (&buf, 0, sizeof buf);
		Draw_Underline (3, 5, 3);
		rt = Get_String (3, 5, 3, buf);
		if (rt == -1)											/* skip	*/
			Disp_Msg ("<����> �Է� (Esc:Cancel)");
		else if (rt == -4)									/* Space	*/
			Disp_Msg ("You cannot input SPACE (Esc:Cancel)");
		else if (rt == 1)										/* Esc	*/
			return;
		else
		{
			attron (A_UNDERLINE);
			mvaddstr (3, 5, buf);
			attroff (A_UNDERLINE);

			if (strlen (buf) != 2)
			{
				Disp_Msg ("���� ���� (Esc:Cancel)");
				continue;
			}

			In_Arry = AtoIf(buf, 2);
			break;
		}
	}

	return;
}

/*----------------------------------------------------------------------*/
static void		Disp_Sise (void)
/*----------------------------------------------------------------------*/
{
	SIF_CURR	fms_curr;
	SIF_G7		fms_c0;
	SIO_CURR	opt_curr;
	SIO_G7		opt_c0;

	G_Time ();

	attron (A_REVERSE);

	if (FO_Flag == 1)											/* ����	*/
	{
		mvaddstr (4, 0, "�������� ���簡 (Futures_CURR)");
		Curr_Arry = Shm_Futures[Sk].CURR_Arry_Key;

		Curr_Arry = (Curr_Arry + In_Arry) % 30;
		if (Curr_Arry < 0)
			Curr_Arry += 30;
		else if (Curr_Arry > 30)
			Curr_Arry -= 30;

		memcpy (fms_curr.tr_gbn, 
				Shm_Futures[Sk].Futures_CURR_Arry[Curr_Arry].tr_gbn, 
				sizeof (SIF_G7));
	}
	else if (FO_Flag == 2)										/* �ɼ�	*/
	{
		mvaddstr (4, 0, "�����ɼ� ���簡 (Options_CURR)");
		Curr_Arry = Shm_Options[Sk].CURR_Arry_Key;

		Curr_Arry = (Curr_Arry + In_Arry) % 30;
		if (Curr_Arry < 0)
			Curr_Arry += 30;
		else if (Curr_Arry > 30)
			Curr_Arry -= 30;

		memcpy (opt_curr.tr_gbn, 
				Shm_Options[Sk].Options_CURR_Arry[Curr_Arry].tr_gbn,
				sizeof (SIO_G7));
	}
	else
	{
		mvaddstr (4, 0, "ELW ���簡 (ELW_CURR)");
		Curr_Arry = Shm_Elw[Sk].CURR_Arry_Key;

		Curr_Arry = (Curr_Arry + In_Arry) % 30;
		if (Curr_Arry < 0)
			Curr_Arry += 30;
		else if (Curr_Arry > 30)
			Curr_Arry -= 30;

	}

	attroff (A_REVERSE);

	attron (A_BOLD);
	
	MvAddNum (3, 5, 3, In_Arry);							/* ���� */

	if (FO_Flag == 2)										/* ����	*/
	{
		MvAddStr (5, 10, 10, Shm_Options[0].ordertime);
		MvAddStr (5, 33, 10, Shm_Options[0].chetime);
        MvAddStr (6, 9, 8, opt_curr.item_code+3);
        MvAddStr (6, 33, 30, Shm_Options[Sk].Options_A0.kor_nm);
        MvAddStr (8, 7, 4, Shm_Options[Sk].Options_A0.hlprc+6);
        MvAddStr (8, 12, 2, Shm_Options[Sk].Options_A0.hlprc+10);
        MvAddStr (8, 25, 4, Shm_Options[Sk].Options_A0.llprc+6);
        MvAddStr (8, 30, 2, Shm_Options[Sk].Options_A0.llprc+10);
        MvAddStr (9, 7, 3, opt_curr.oprc);
        MvAddStr (9, 11, 2, opt_curr.oprc+3);
        MvAddStr (9, 23, 3, opt_curr.hprc);
        MvAddStr (9, 27, 2, opt_curr.hprc+3);
        MvAddStr (9, 41, 3, opt_curr.lprc);
        MvAddStr (9, 45, 2, opt_curr.lprc+3);
		MvAddStr (10, 9, 7, opt_curr.chekyul_qty);
        MvAddStr (10, 29, 8, opt_curr.tot_con_qty);
        MvAddStr (10, 56, 11, opt_curr.tot_con_amt);

        /* ���簡 */
        MvAddStr (12, 7, 3, opt_curr.crprc);
        MvAddStr (12, 11, 2, opt_curr.crprc+3);
        /* �켱ȣ�� */
        MvAddStr (13, 14, 3, opt_curr.sel_1_prmbid);
        MvAddStr (13, 18, 2, opt_curr.sel_1_prmbid+3);
        MvAddStr (13, 40, 3, opt_curr.buy_1_prmbid);
        MvAddStr (13, 44, 2, opt_curr.buy_1_prmbid+3);
        MvAddStr (14, 14, 3, opt_curr.sel_2_prmbid);
        MvAddStr (14, 18, 2, opt_curr.sel_2_prmbid+3);
        MvAddStr (14, 40, 3, opt_curr.buy_2_prmbid);
        MvAddStr (14, 44, 2, opt_curr.buy_2_prmbid+3);
        MvAddStr (15, 14, 3, opt_curr.sel_3_prmbid);
        MvAddStr (15, 18, 2, opt_curr.sel_3_prmbid+3);
        MvAddStr (15, 40, 3, opt_curr.buy_3_prmbid);
        MvAddStr (15, 44, 2, opt_curr.buy_3_prmbid+3);
        MvAddStr (16, 14, 3, opt_curr.sel_4_prmbid);
        MvAddStr (16, 18, 2, opt_curr.sel_4_prmbid+3);
        MvAddStr (16, 40, 3, opt_curr.buy_4_prmbid);
        MvAddStr (16, 44, 2, opt_curr.buy_4_prmbid+3);
        MvAddStr (17, 14, 3, opt_curr.sel_5_prmbid);
        MvAddStr (17, 18, 2, opt_curr.sel_5_prmbid+3);
        MvAddStr (17, 40, 3, opt_curr.buy_5_prmbid);
        MvAddStr (17, 44, 2, opt_curr.buy_5_prmbid+3);
        /* �� ȣ������ */
        MvAddStr (19, 15, 7, opt_curr.sel_tot_best_qty);
        MvAddStr (19, 41, 7, opt_curr.buy_tot_best_qty);
        /* ȣ������ */
        MvAddStr (20, 18, 7, opt_curr.sel_1_prmbid_qty);
        MvAddStr (20, 44, 7, opt_curr.buy_1_prmbid_qty);
        MvAddStr (21, 18, 7, opt_curr.sel_2_prmbid_qty);
        MvAddStr (21, 44, 7, opt_curr.buy_2_prmbid_qty);
        MvAddStr (22, 18, 7, opt_curr.sel_3_prmbid_qty);
        MvAddStr (22, 44, 7, opt_curr.buy_3_prmbid_qty);
        MvAddStr (23, 18, 7, opt_curr.sel_4_prmbid_qty);
        MvAddStr (23, 44, 7, opt_curr.buy_4_prmbid_qty);
        MvAddStr (24, 18, 7, opt_curr.sel_5_prmbid_qty);
        MvAddStr (24, 44, 7, opt_curr.buy_5_prmbid_qty);
        /* �� ȣ���Ǽ� */
        MvAddStr (26, 15, 5, opt_curr.sel_tot_best_cnt);
        MvAddStr (26, 41, 5, opt_curr.buy_tot_best_cnt);
        /* ȣ���Ǽ� */
        MvAddStr (27, 18, 4, opt_curr.sel_1_best_cnt);
        MvAddStr (27, 44, 4, opt_curr.buy_1_best_cnt);
        MvAddStr (28, 18, 4, opt_curr.sel_2_best_cnt);
        MvAddStr (28, 44, 4, opt_curr.buy_2_best_cnt);
        MvAddStr (29, 18, 4, opt_curr.sel_3_best_cnt);
        MvAddStr (29, 44, 4, opt_curr.buy_3_best_cnt);
        MvAddStr (30, 18, 4, opt_curr.sel_4_best_cnt);
        MvAddStr (30, 44, 4, opt_curr.buy_4_best_cnt);
        MvAddStr (31, 18, 4, opt_curr.sel_5_best_cnt);
        MvAddStr (31, 44, 4, opt_curr.buy_5_best_cnt);
	}
	else if (FO_Flag == 1)								/* ����	*/
	{
		MvAddStr (5, 10, 10, Shm_Futures[0].ordertime);
/*
		MvAddStr (5, 33, 10, Shm_Futures[0].chetime);
*/
        MvAddStr (5, 33, 8, fms_curr.chekyul_tm);

		MvAddStr (6, 9, 8, fms_curr.item_code+3);
		MvAddStr (6, 33, 30, Shm_Futures[Sk].Futures_A0.kor_nm);
		MvAddStr (8, 7, 4, Shm_Futures[Sk].Futures_A0.hlprc+6);
		MvAddStr (8, 12, 2, Shm_Futures[Sk].Futures_A0.hlprc+10);
		MvAddStr (8, 25, 4, Shm_Futures[Sk].Futures_A0.llprc+6);
		MvAddStr (8, 30, 2, Shm_Futures[Sk].Futures_A0.llprc+10);
		MvAddStr (9, 7, 3, fms_curr.oprc);
		MvAddStr (9, 11, 2, fms_curr.oprc+3);
		MvAddStr (9, 23, 3, fms_curr.hprc);
		MvAddStr (9, 27, 2, fms_curr.hprc+3);
		MvAddStr (9, 41, 3, fms_curr.lprc);
		MvAddStr (9, 45, 2, fms_curr.lprc+3);
		MvAddStr (10, 9, 6, fms_curr.chekyul_qty);
		MvAddStr (10, 29, 7, fms_curr.tot_con_qty);
		MvAddStr (10, 56, 11, fms_curr.tot_con_amt);

		/* ���簡 */
		MvAddStr (12, 7, 3, fms_curr.crprc);
		MvAddStr (12, 11, 2, fms_curr.crprc+3);
		/* �켱ȣ�� */
		MvAddStr (13, 14, 3, fms_curr.sel_1_prmbid);
		MvAddStr (13, 18, 2, fms_curr.sel_1_prmbid+3);
		MvAddStr (13, 40, 3, fms_curr.buy_1_prmbid);
		MvAddStr (13, 44, 2, fms_curr.buy_1_prmbid+3);
		MvAddStr (14, 14, 3, fms_curr.sel_2_prmbid);
		MvAddStr (14, 18, 2, fms_curr.sel_2_prmbid+3);
		MvAddStr (14, 40, 3, fms_curr.buy_2_prmbid);
		MvAddStr (14, 44, 2, fms_curr.buy_2_prmbid+3);
		MvAddStr (15, 14, 3, fms_curr.sel_3_prmbid);
		MvAddStr (15, 18, 2, fms_curr.sel_3_prmbid+3);
		MvAddStr (15, 40, 3, fms_curr.buy_3_prmbid);
		MvAddStr (15, 44, 2, fms_curr.buy_3_prmbid+3);
		MvAddStr (16, 14, 3, fms_curr.sel_4_prmbid);
		MvAddStr (16, 18, 2, fms_curr.sel_4_prmbid+3);
		MvAddStr (16, 40, 3, fms_curr.buy_4_prmbid);
		MvAddStr (16, 44, 2, fms_curr.buy_4_prmbid+3);
		MvAddStr (17, 14, 3, fms_curr.sel_5_prmbid);
		MvAddStr (17, 18, 2, fms_curr.sel_5_prmbid+3);
		MvAddStr (17, 40, 3, fms_curr.buy_5_prmbid);
		MvAddStr (17, 44, 2, fms_curr.buy_5_prmbid+3);
		/* �� ȣ������ */
		MvAddStr (19, 15, 6, fms_curr.sel_tot_best_qty);
		MvAddStr (19, 41, 6, fms_curr.buy_tot_best_qty);
		/* ȣ������ */
		MvAddStr (20, 18, 6, fms_curr.sel_1_prmbid_qty);
		MvAddStr (20, 44, 6, fms_curr.buy_1_prmbid_qty);
		MvAddStr (21, 18, 6, fms_curr.sel_2_prmbid_qty);
		MvAddStr (21, 44, 6, fms_curr.buy_2_prmbid_qty);
		MvAddStr (22, 18, 6, fms_curr.sel_3_prmbid_qty);
		MvAddStr (22, 44, 6, fms_curr.buy_3_prmbid_qty);
		MvAddStr (23, 18, 6, fms_curr.sel_4_prmbid_qty);
		MvAddStr (23, 44, 6, fms_curr.buy_4_prmbid_qty);
		MvAddStr (24, 18, 6, fms_curr.sel_5_prmbid_qty);
		MvAddStr (24, 44, 6, fms_curr.buy_5_prmbid_qty);
		/* �� ȣ���Ǽ� */
		MvAddStr (26, 15, 5, fms_curr.sel_tot_best_cnt);
		MvAddStr (26, 41, 5, fms_curr.buy_tot_best_cnt);
		/* ȣ���Ǽ� */
		MvAddStr (27, 18, 4, fms_curr.sel_1_best_cnt);
		MvAddStr (27, 44, 4, fms_curr.buy_1_best_cnt);
		MvAddStr (28, 18, 4, fms_curr.sel_2_best_cnt);
		MvAddStr (28, 44, 4, fms_curr.buy_2_best_cnt);
		MvAddStr (29, 18, 4, fms_curr.sel_3_best_cnt);
		MvAddStr (29, 44, 4, fms_curr.buy_3_best_cnt);
		MvAddStr (30, 18, 4, fms_curr.sel_4_best_cnt);
		MvAddStr (30, 44, 4, fms_curr.buy_4_best_cnt);
		MvAddStr (31, 18, 4, fms_curr.sel_5_best_cnt);
		MvAddStr (31, 44, 4, fms_curr.buy_5_best_cnt);
	}
	else												/* ELW	*/
	{
        MvAddStr (6, 9, 9, Shm_Elw[Sk].Elw_Master.compress_code);
        MvAddStr (6, 33, 30, Shm_Elw[Sk].Elw_Master.name);
        MvAddStr (8, 7, 7, Shm_Elw[Sk].Elw_Master.high_limit_price+2);
        MvAddStr (8, 25, 7, Shm_Elw[Sk].Elw_Master.low_limit_price+2);
        MvAddStr (9, 7, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].opening_price+3);
        MvAddStr (9, 23, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].highest_price+3);
        MvAddStr (9, 41, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].lowest_price+3);
		MvAddStr (10, 9, 7, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].trade_qty+3);
        MvAddStr (10, 29, 8, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].accum_trade_qty+4);
        MvAddStr (10, 56, 18, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].accum_trade_amt);

        /* ���簡 */
        MvAddStr (12, 7, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].current_price+3);
        /* �켱ȣ�� */
        MvAddStr (13, 14, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[0].offer+3);
        MvAddStr (13, 40, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[0].bid+3);
        MvAddStr (14, 14, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[1].offer+3);
        MvAddStr (14, 40, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[1].bid+3);
        MvAddStr (15, 14, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[2].offer+3);
        MvAddStr (15, 40, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[2].bid+3);
        MvAddStr (16, 14, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[3].offer+3);
        MvAddStr (16, 40, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[3].bid+3);
        MvAddStr (17, 14, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[4].offer+3);
        MvAddStr (17, 40, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[4].bid+3);

		mvaddstr (18, 0, "�ջ�");
        /* �� ȣ������ */
        MvAddStr (19, 15, 7, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].tot_offer_qty+5);
        MvAddStr (19, 41, 7, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].tot_bid_qty+5);
        /* ȣ������ */
        MvAddStr (20, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[0].offer_qty+6);
        MvAddStr (20, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[0].bid_qty+6);
        MvAddStr (21, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[1].offer_qty+6);
        MvAddStr (21, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[1].bid_qty+6);
        MvAddStr (22, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[2].offer_qty+6);
        MvAddStr (22, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[2].bid_qty+6);
        MvAddStr (23, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[3].offer_qty+6);
        MvAddStr (23, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[3].bid_qty+6);
        MvAddStr (24, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[4].offer_qty+6);
        MvAddStr (24, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[4].bid_qty+6);

		mvaddstr (25, 0, "LP");
        /* ȣ������(LP) */
        MvAddStr (27, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[0].LP_offer_qty+6);
        MvAddStr (27, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[0].LP_bid_qty+6);
        MvAddStr (28, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[1].LP_offer_qty+6);
        MvAddStr (28, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[1].LP_bid_qty+6);
        MvAddStr (29, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[2].LP_offer_qty+6);
        MvAddStr (29, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[2].LP_bid_qty+6);
        MvAddStr (30, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[3].LP_offer_qty+6);
        MvAddStr (30, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[3].LP_bid_qty+6);
        MvAddStr (31, 18, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[4].LP_offer_qty+6);
        MvAddStr (31, 44, 6, Shm_Elw[Sk].Elw_Curr_Arry[Curr_Arry].hoga[4].LP_bid_qty+6);
	}

	attroff (A_BOLD);

	return;
}

/*************************************************************************
	End of Program (py_2040_cm.c)
*************************************************************************/
