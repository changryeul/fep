#define     _GLOBAL
/*------------------------------------------------------------------------
#   System  : PK_C/OS System Sync방식
#   Module  : Online 업무 수신
#   File    : jw_3010_tr.c
------------------------------------------------------------------------*/

/*------------------------------------------------------------------------
    Header Files
------------------------------------------------------------------------*/
#include    "fep_fepj.h"

/*------------------------------------------------------------------------
    Constants and Structures
------------------------------------------------------------------------*/
#define     TCP_TIME_OUT    15

/*------------------------------------------------------------------------
    Global Variables
------------------------------------------------------------------------*/
int     Sockfd, PktType, Pk[20], DataSize, MaxCnt;
char    ApType[10], RecvPkt[TCP_BUFF_MAX_LEN], SendPkt[TCP_BUFF_MAX_LEN];

TCP_MESSAGE     *R_Pkt = (TCP_MESSAGE *)RecvPkt;
TCP_HEAD        *S_Pkt = (TCP_HEAD *)SendPkt;

/*------------------------------------------------------------------------
    Function Prototypes
------------------------------------------------------------------------*/
void    JW_3010_TR(int, char **);
void    Init_Parameters(void);
int     Receive_Packet(void);
int     Send_Packet(void);
int     Write_Data(void);
int     Check_Jang_Status(void);
int     Check_Header(void);
void    Register_Signal(void);
void    Catch_Signal(int);
/*----------------------------------------------------------------------*/
int     main(int argc, char *argv[])
/*----------------------------------------------------------------------*/
{
    Init_Proc(argc, argv);
    JW_3010_TR(argc, argv);

    TCP1_NET_STA = OFF;
    close(Sockfd);
    Exit_Process();
}   /* End of main ()   */

/*----------------------------------------------------------------------*/
void    JW_3010_TR(int argc, char **argv)
/*----------------------------------------------------------------------*/
{
    int     rt;

    Register_Signal();
    Init_Parameters();

    if (argc != 3) {
        Log(USR_FATAL, "invalid arguments number[%d]", argc);
        Exit_Process();
    }

    Sockfd = AtoIf(argv[1], strlen(argv[1]));
    PROC(D_K,P_K).l.t1.line_gubun = AtoIf(argv[2], 1);
    PROC(D_K,P_K).l.t1.port_type = AtoIf(&argv[2][2], 1);
    Log(USR_OK, "Sockfd[%d] line_gubun[%d] port_type[%d]",
            Sockfd, PROC(D_K,P_K).l.t1.line_gubun, PROC(D_K,P_K).l.t1.port_type);

    Set_Socket_Linger(Sockfd);

    PktType = T_STOK;
    rt = Send_Packet();
    if (rt == NOTOK)
        return;

    while (START_S < JOB_END) {
        Stat_Save();

        rt = Receive_Packet();
        if (rt == NOTOK)
            break;
        else if (rt == FAIL)
            continue;

        rt = Send_Packet();
        if (rt == NOTOK)
            break;
    }

    return;
}   /* End of JW_3010_TR () */

/*************************************************************************
    Function        : . Init_Parameters
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . void
    Comment         : . initiate the global variables
*************************************************************************/
/*----------------------------------------------------------------------*/
void    Init_Parameters(void)
/*----------------------------------------------------------------------*/
{
    int     i;
    char    chk_proc[12];

    SYS_NO = 0;

    if (TIME_OUT == 0)
        TIME_OUT = TCP_TIME_OUT;

    sprintf(ApType, "%-2.2s%-4.4s%-2.2s", _Exe_Name, _Exe_Name+3, _Exe_Name+8);
    LtoU(ApType, strlen(ApType));

#ifdef SAM_USE
    DataSize = OFS(D_K,P_K,0);
#else
    DataSize = ODS(D_K,P_K,0);
#endif
    MaxCnt = FILE_BUF_LEN / (sizeof (FILE_RW_HEAD) + DataSize + 1);

    for (i = 0; i < PROC_MAX; i ++) {
        if (PROC_MAX == 1)
            sprintf(chk_proc, "%-5.5s01_ts", _Exe_Name);
        else
            sprintf(chk_proc, "%-5.5s0%d_ts", _Exe_Name, i + 1);

        for (Pk[i] = 0; Pk[i] < DAEMON(D_K).p_count; Pk[i] ++) {
            if (memcmp(PROC(D_K,Pk[i]).process_id, chk_proc, 10) == 0)
                break;

            if (Pk[i] == DAEMON(D_K).p_count - 1) {
                Log(USR_FATAL, "unregistered process[%s]", chk_proc);
                TCP1_NET_STA = OFF;
                close(Sockfd);
                Exit_Process();
            }
        }
    }

    return;
}  /* End of Init_Parameters () */

/*************************************************************************
    Function        : . Receive_Packet
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . int (0:success, -1:failure, 1:interrupted)
    Comment         : . receive packet
*************************************************************************/
/*----------------------------------------------------------------------*/
int     Receive_Packet(void)
/*----------------------------------------------------------------------*/
{
    int     rt, recv_len, seq;

    memset(RecvPkt, 0, sizeof (RecvPkt));

    rt = Select_Receive(Sockfd, RecvPkt);

    if (rt == OK)
        return (NOTOK);
    else if (rt == NOTOK) {
        if (SYS_NO == EINTR)
            return (FAIL);

        return (NOTOK);
    }

    Log(TCP_OK, "TCP RD [%s](%d)<%d>", RecvPkt, strlen(RecvPkt), INT_SEQ);

    recv_len = strlen(RecvPkt);

    if (recv_len < TCP_HEAD_LEN || recv_len != rt ||
            recv_len > TCP_MESSAGE_MAX_LEN) {
        Log(USR_ERROR, "invalid length[%d,%d]", recv_len, rt);
        PktType = T_LNTH;
        Send_Packet();
        return (NOTOK);
    }

    if (memcmp(R_Pkt->Head.MsgType, TCP_STOP_CD, strlen(TCP_STOP_CD)) == 0) {
        Log(USR_OK, "received STOP request");
        TCP1_NET_STA = END;
        close(Sockfd);
        Exit_Process();
    }
    else if (memcmp(R_Pkt->Head.MsgType,
            TCP_POLL_CD, strlen(TCP_POLL_CD)) == 0) {
        seq = AtoIf(R_Pkt->Head.SeqNo, sizeof (R_Pkt->Head.SeqNo));

        if (seq != INT_SEQ)
            Log(USR_WARN, "POLL:SeqNo [%d:%d]", seq, INT_SEQ);

        PktType = T_POOK;
    }
    else if (memcmp(R_Pkt->Head.MsgType,
            TCP_DATA_CD, strlen(TCP_DATA_CD)) == 0) {
        PktType = T_DAOK;
    }
    else {
        Log(USR_ERROR, "TCP header(MsgType) [%.4s:%s]",
                R_Pkt->Head.MsgType, TCP_DATA_CD);
        memcpy(R_Pkt->Head.ResponseCode, ERR_HEAD_T7, strlen(ERR_HEAD_T7));
        PktType = T_EROR;
        Send_Packet();
        return (NOTOK);
    }

    return (OK);
}   /* Receive_Packet ()    */

/*************************************************************************
    Function        : . Send_Packet
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . int (0:success, -1:failure)
    Comment         : . send packet
*************************************************************************/
/*----------------------------------------------------------------------*/
int     Send_Packet(void)
/*----------------------------------------------------------------------*/
{
    int     rt;
    char    error_flag, t_time[12];

    error_flag = OFF;
    memset(SendPkt, 0, sizeof (SendPkt));

    if (PktType == T_STOK)
        memset(SendPkt, ' ', TCP_HEAD_LEN);
    else
        memcpy(SendPkt, RecvPkt, TCP_HEAD_LEN);

    if (PktType != T_EROR) {
        S_Pkt->Stx[0] = STX;
        ItoAf(TCP_HEAD_LEN, S_Pkt->Length, sizeof (S_Pkt->Length));
        memcpy(S_Pkt->ApType, ApType, sizeof (S_Pkt->ApType));
        memcpy(S_Pkt->Date, DATE_CURR, sizeof (S_Pkt->Date));
        memset(t_time, 0, sizeof (t_time));
        Get_Time(t_time);
        memcpy(S_Pkt->Time, t_time, sizeof (S_Pkt->Time));
        ItoAf(0, S_Pkt->DataCnt, sizeof (S_Pkt->DataCnt));
    }

    switch (PktType) {
        case    T_STOK:
            ItoAf(0, S_Pkt->ResponseCode, sizeof (S_Pkt->ResponseCode));
            memcpy(S_Pkt->MsgType, TCP_STOK_CD, sizeof (S_Pkt->MsgType));
            break;
        case    T_POOK:
            rt = Check_Jang_Status();
            if (rt == OK)
                ItoAf(0, S_Pkt->ResponseCode, sizeof (S_Pkt->ResponseCode));

            memcpy(S_Pkt->MsgType, TCP_POOK_CD, sizeof (S_Pkt->MsgType));
            break;
        case    T_LNTH:
            memcpy(S_Pkt->ResponseCode, ERR_HEAD_T2, strlen(ERR_HEAD_T2));
            memcpy(S_Pkt->MsgType+2, "OK", 2);
            break;
        case    T_DAOK:
            rt = Check_Jang_Status();
            if (rt == OK) {
                rt = Check_Header();
                if (rt == OK) {
                    rt = Write_Data();
                    if (rt != OK)
                        error_flag = ON;
            }
            else
                error_flag = ON;
        }
        else
            Log(USR_ERROR, "check jang status[%.4s]", S_Pkt->ResponseCode);

        memcpy(S_Pkt->MsgType, TCP_DAOK_CD, sizeof (S_Pkt->MsgType));
        break;
        default:
            break;
    }

    if (PktType != T_EROR)
        ItoAf(INT_SEQ, S_Pkt->SeqNo, sizeof (S_Pkt->SeqNo));

    rt = Select_Send(Sockfd, SendPkt, TCP_HEAD_LEN);

    if (rt != OK)
        return (NOTOK);

    if (PktType == T_STOK)
        TCP1_NET_STA = ON;
    /*
        else
            Log (TCP_OK, "TCP RD [%s](%d)<%d>", RecvPkt, strlen (RecvPkt), INT_SEQ);
    */

    Log(TCP_OK, "TCP SD [%s](%d)<%d>", SendPkt, strlen(SendPkt), INT_SEQ);

    if (PktType == T_LNTH || error_flag == ON)
        return (NOTOK);

    return (OK);
}   /* Send_Packet ()   */

/*************************************************************************
    Function        : . Write_Data
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . int (0:success, -1:failure)
    Comment         : . write received data to file
*************************************************************************/
/*----------------------------------------------------------------------*/
int     Write_Data(void)
/*----------------------------------------------------------------------*/
{
    int             i, next, seq, d_cnt, rt, len, f_size, rec_size;
    char            m_time[24], w_buf[FILE_BUF_LEN];
    char            *data = (char *)R_Pkt->Data;
    BUFF_RW_HEAD    f_head;

    d_cnt = AtoIf(R_Pkt->Head.DataCnt, sizeof (R_Pkt->Head.DataCnt));
    f_size = sizeof (BUFF_RW_HEAD);
    rec_size = f_size + DataSize + 1;

    memset(m_time, 0, sizeof (m_time));
    Get_MicroTime(m_time);

    memset(w_buf, ' ', sizeof (w_buf));

    for (i = 0, next = 0; i < d_cnt; i ++) {
        pTcp_Data_Head = (TCP_DATA_HEAD *)(data+next);

        seq = AtoIf(pTcp_Data_Head->DataSeq, sizeof (pTcp_Data_Head->DataSeq));
        if (seq != INT_SEQ + i + 1) {
            Log(USR_ERROR, "data header(DataSeq) [%d:%d]",
                    seq, INT_SEQ + i + 1);
            memcpy(S_Pkt->ResponseCode, ERR_HEAD_D2, strlen(ERR_HEAD_D2));
            return (NOTOK);
        }

        len = AtoIf(pTcp_Data_Head->Length, sizeof (pTcp_Data_Head->Length));
        if (len <= HEAD_SIZE || len > HEAD_SIZE + DataSize) {
            Log(USR_ERROR, "data header(Length) [%d:%d]",
                    len, HEAD_SIZE + DataSize);
            memcpy(S_Pkt->ResponseCode, ERR_HEAD_D1, strlen(ERR_HEAD_D1));
            return (NOTOK);
        }

        memcpy(f_head.DataHeader, data+next, HEAD_SIZE);
        ItoAf(INT_SEQ + i + 1, f_head.If_Seq, sizeof (f_head.If_Seq));
        memcpy(f_head.ApType, ApType, strlen(ApType));
        ItoAf(0, f_head.ResponseCode, sizeof (f_head.ResponseCode));
        memcpy(f_head.RecvTime1, m_time, sizeof (f_head.RecvTime1));
        memcpy(f_head.RecvTime2, &m_time[sizeof(f_head.RecvTime1)],
                sizeof (f_head.RecvTime2));

        memcpy(&w_buf[rec_size*i], &f_head, f_size);
        memcpy(&w_buf[rec_size*i+f_size], data+next+HEAD_SIZE,
                len - HEAD_SIZE);
        w_buf[rec_size*i+f_size+DataSize] = '\n';

        next += len;
    }

    SYS_NO = 0;

#ifdef SAM_USE
    rt = F_W(TS_W1_1, w_buf, d_cnt);

    if (rt != d_cnt) {
        Log(DSH_FATAL, "File write[%s]", OFN(D_K,P_K,0));
        memcpy(S_Pkt->ResponseCode, ERR_FILE_WRITE, strlen(ERR_FILE_WRITE));
        return (NOTOK);
    }

    INT_SEQ += d_cnt;
    Set_TR_Time();
    Log(USR_OK, "File write[%s:%d:%d]", OFN(D_K,P_K,0), OFW(D_K,P_K,0,0), d_cnt);
    ItoAf(d_cnt, S_Pkt->DataCnt, sizeof (S_Pkt->DataCnt));
#else
    rt = DSHM_W(TS_W1_1, w_buf, d_cnt);

    if (rt != d_cnt) {
        Log(DSH_FATAL, "DSHM write[%s]", ODN(D_K,P_K,0));
        memcpy(S_Pkt->ResponseCode, ERR_FILE_WRITE, strlen(ERR_FILE_WRITE));
        return (NOTOK);
    }

    INT_SEQ += d_cnt;
    Set_TR_Time();
    Log(USR_OK, "DSHM write[%s:%d:%d]", ODN(D_K,P_K,0), ODW(D_K,P_K,0,0), d_cnt);
    ItoAf(d_cnt, S_Pkt->DataCnt, sizeof (S_Pkt->DataCnt));

#endif

    return (OK);
}   /* End of Write_Data () */

/*************************************************************************
    Function        : . Check_Jang_Status
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . int (0:success, -1:failure)
    Comment         : . check validity of jang status
*************************************************************************/
/*----------------------------------------------------------------------*/
int     Check_Jang_Status(void)
/*----------------------------------------------------------------------*/
{
    int     i, off_f, end_f, stop_f, off_l;
    u_char  nstat, lstat;

    off_f = end_f = stop_f = off_l = 0;

    if (PROC_MAX == 0)
        return (OK);

    for (i = 0; i < PROC_MAX; i ++) {
        nstat = TCP2_NSTAT(D_K,Pk[i],TCP2_LINE_GUBUN(D_K,Pk[i]));
        lstat = TCP2_LSTAT(D_K,Pk[i],TCP2_LINE_GUBUN(D_K,Pk[i]));

        if (nstat == ON && lstat == ON)
            return (OK);
        else if (nstat == OFF)
            off_f ++;
        else if (nstat == END)
            end_f ++;
        else if (nstat == JOB_STOP)
            stop_f ++;
        else if (lstat == OFF)
            off_l ++;

    }

    if (off_f == PROC_MAX && INT_SEQ == 0)
        memcpy(S_Pkt->ResponseCode, ERR_JANG_BEFORE, strlen(ERR_JANG_BEFORE));
    else if (end_f == PROC_MAX && off_l < PROC_MAX)
        memcpy(S_Pkt->ResponseCode, ERR_JANG_END, strlen(ERR_JANG_END));
    else if (stop_f == PROC_MAX && off_l < PROC_MAX)
        memcpy(S_Pkt->ResponseCode, ERR_JANG_STOP, strlen(ERR_JANG_STOP));
    else
        memcpy(S_Pkt->ResponseCode, ERR_JANG_ERROR, strlen(ERR_JANG_ERROR));

    return (NOTOK);
}   /* End of Check_Jang_Status ()  */

/*************************************************************************
    Function        : . Check_Header
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . int (0:success, -1:failure)
    Comment         : . check validity of the received header
*************************************************************************/
/*----------------------------------------------------------------------*/
int     Check_Header(void)
/*----------------------------------------------------------------------*/
{
    int     val;

    /* Stx (0x02)   */
    if (R_Pkt->Head.Stx[0] != STX) {
        Log(USR_ERROR, "TCP header(Stx) [%#04x:%#04x]",
                R_Pkt->Head.Stx[0], STX);
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T1, strlen(ERR_HEAD_T1));
        return (NOTOK);
    }

    /* Length (packet 총 길이) */
    val = AtoIf(R_Pkt->Head.Length, sizeof (R_Pkt->Head.Length));
    if (val != strlen(RecvPkt) || strlen(RecvPkt) <= TCP_HEAD_LEN) {
        Log(USR_ERROR, "TCP header(Length) [%d:%d]", val, strlen(RecvPkt));
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T2, strlen(ERR_HEAD_T2));
        return (NOTOK);
    }

    /* ApType (업무구분식별자) */
    if (memcmp(R_Pkt->Head.ApType, ApType, sizeof (R_Pkt->Head.ApType)) != 0) {
        Log(USR_ERROR, "TCP header(ApType) [%.8s:%s]",
                R_Pkt->Head.ApType, ApType);
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T3, strlen(ERR_HEAD_T3));
        return (NOTOK);
    }

    /* ResponseCode (응답코드)  */
    if (AtoIf(R_Pkt->Head.ResponseCode,
            sizeof (R_Pkt->Head.ResponseCode)) != 0) {
        Log(USR_ERROR, "TCP header(ResponseCode) [%.4s:%04d]",
                R_Pkt->Head.ResponseCode, 0);
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T6, strlen(ERR_HEAD_T6));
        return (NOTOK);
    }

    /* MsgType (운영코드)   */
    if (memcmp(R_Pkt->Head.MsgType, TCP_DATA_CD, strlen(TCP_DATA_CD)) != 0) {
        Log(USR_ERROR, "TCP header(MsgType) [%.4s:%s]",
                R_Pkt->Head.MsgType, TCP_DATA_CD);
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T7, strlen(ERR_HEAD_T7));
        return (NOTOK);
    }

    /* SeqNo (일련번호) */
    val = AtoIf(R_Pkt->Head.SeqNo, sizeof (R_Pkt->Head.SeqNo));
    if (val != INT_SEQ + 1) {
        Log(USR_ERROR, "TCP header(SeqNo) [%d:%d]", val, INT_SEQ + 1);
        ItoAf(INT_SEQ, S_Pkt->SeqNo, sizeof (S_Pkt->SeqNo));
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T8, strlen(ERR_HEAD_T8));
        return (NOTOK);
    }

    /* DataCnt (한 packet 내 blocking된 data 건수)   */
    val = AtoIf(R_Pkt->Head.DataCnt, sizeof (R_Pkt->Head.DataCnt));
    if (val < 1 || val > MaxCnt) {
        Log(USR_ERROR, "TCP header(DataCnt) [%d:%d]", val, MaxCnt);
        memcpy(S_Pkt->ResponseCode, ERR_HEAD_T9, strlen(ERR_HEAD_T9));
        return (NOTOK);
    }

    return (OK);
}   /* End of Check_Header ()   */

/*************************************************************************
    Function        : . Register_Signal
    Parameters IN   : .
    Parameters OUT  : .
    Return Code     : . void
    Comment         : . register signals
*************************************************************************/
/*----------------------------------------------------------------------*/
void    Register_Signal(void)
/*----------------------------------------------------------------------*/
{
    struct sigaction    act;

    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    act.sa_handler = Catch_Signal;

    if (sigaction(SIGPIPE, &act, NULL) < 0) {
        Log(SYS_ERROR, "sigaction(SIGPIPE) {%d:%s}", SYS_NO, SYS_STR);
        return;
    }

    if (sigaction(SIGTERM, &act, NULL) < 0) {
        Log(SYS_ERROR, "sigaction(SIGTERM) {%d:%s}", SYS_NO, SYS_STR);
        return;
    }

    return;
}   /* End of Register_Signal ()    */

/*************************************************************************
    Function        : . Catch_Signal
    Parameters IN   : . signo : signal number
    Parameters OUT  : .
    Return Code     : . void
    Comment         : . catch signal
*************************************************************************/
/*----------------------------------------------------------------------*/
void    Catch_Signal(int signo)
/*----------------------------------------------------------------------*/
{
    _in_signal_handler = 1;
    SIG_WRITE_MSG("[SIGNAL] pw_3010_tr caught signal\n");

    TCP1_NET_STA = OFF;
    close(Sockfd);
    Exit_Process();
}   /* End of Catch_Signal ()   */

/*************************************************************************
    End of Program (jw_3010_tr.c)
*************************************************************************/
