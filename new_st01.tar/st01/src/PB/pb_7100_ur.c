#define     _GLOBAL
/*------------------------------------------------------------------------
 *  Module  : 채권 시세수신 (UDP 멀티캐스트)
 *  File    : pb_7100_ur.c
 *
 *  KRX로부터 UDP 멀티캐스트로 채권 시세를 수신하여
 *  TCP로 연결된 서버에 재전송하는 프로세스.
 *
 *  빌드 옵션:
 *    B7102 : 채권시세 (700B) - 체결+호가 데이터
 *    B7103 : 채권시세 (100B) - 장운영 데이터
 *
 *  처리 흐름:
 *    1) UDP 멀티캐스트 소켓 생성 및 Join (Socket_Connect)
 *    2) TCP 서버 연결 (Device_Open)
 *    3) UDP 수신 데이터를 TR코드별 분류
 *    4) A3/G7/B6/M4 → TCP 전달, 기타 → LK 응답 전송
 *
 *  네트워크 구성:
 *    - UDP: 멀티캐스트 그룹 조인 (udpip.ini 설정)
 *    - TCP: 데이터 재전송용 서버 연결 (tcp2.ini 설정)
 *    - NIC: 개발서버=ens7f3, 운영서버=ens6f3
 *------------------------------------------------------------------------*/

#include    "pa_struct.h"
#include    "fep_fepp.h"

#include    <net/if.h>
#include    <ifaddrs.h>

/* 기본정보채권 KTS 시세 TR코드 목록
 * A701K : 68   장운영 TS
 * M401K : 83   장운영스케줄
 * B601K : 462  일반채권, 국고채권 우선호가
 * A301K : 223  채권체결
 * G701K : 643  일반채권, 국고채권 체결 + 우선호가
 * A601K : 57   채권종목마감
 */

/* 12000: 10 Polling, Log만 File온 처리안함 */

/*------------------------------------------------------------------------
 *  빌드 옵션별 데이터 크기
 *------------------------------------------------------------------------*/
#if defined B7102
#define     DATA_SIZE   700     /* 채권시세(체결+호가) */
#elif defined B7103
#define     DATA_SIZE   100     /* 채권시세(장운영) */
#endif

#include    "buf_struct.h"

/*------------------------------------------------------------------------
 *  Constants and Structures
 *------------------------------------------------------------------------*/
#define     SVR_PORT_NO     UDP_PORT(D_K, P_K, 0)   /* UDP 수신 포트 번호 */
#define     READ_BUF_SIZE   2048                    /* 수신 버퍼 크기 */

/* 시세 Seq 위치 Size */
#define     SH_SIZE     5       /* TR코드(5바이트) */
/* 기본마스터 Seq 위치 Size */
#define     M_H_SIZE    27      /* TR(5) + SEQ(8) + JCNT(6) + DATE(8) */

/*------------------------------------------------------------------------
 *  Global Variables
 *------------------------------------------------------------------------*/
struct sockaddr_in SvrAddr, ClntAddr;   /* UDP 서버/클라이언트 주소 */

int     Sockfd, FIFO_fd, tot_cq;        /* UDP 소켓 fd, FIFO fd, 누적체결수량 */
int     SockTcpfd = -1, PortNo;         /* TCP 소켓 fd, TCP 포트 번호 */
int     Idx, Che_Gbn;                   /* SHM 인덱스, 체결구분 */
struct  ip_mreq mreq;                   /* 멀티캐스트 요청 구조체 */
char    TrCode[8], ApType[10], Order_St[512], IpAddr[20];
char    LogOnFlag, OpenFlag;            /* 로그온/오픈 상태 플래그 */
char    RecvPkt[CLI_BUFF_MAX_LEN], SendPkt[CLI_BUFF_MAX_LEN];

/*------------------------------------------------------------------------
 *  Function Prototypes
 *------------------------------------------------------------------------*/
void    PB_7100_UR(void);
int     Init_Parameters(void);
int     Socket_Connect(void);
int     Recv_Data(char *);
int     Add_Count_UR(void);
int     Add_Count_DD(char *);
int     find_ifname_by_192(char *ifnm);

/*------------------------------------------------------------------------
 *  Device_Open: TCP 서버 연결
 *  - Socket() → Connect()로 TCP 서버에 접속
 *  - TEST/REAL 환경별로 접속 IP/포트가 다름
 *------------------------------------------------------------------------*/
void    Device_Open(void) {
    int rt, rval;

    SockTcpfd = Socket();
    if (SockTcpfd < 0) {
        Log(TCP_ERROR, "socket fail:Sockfd [%d] (%d:%s)", SockTcpfd, SYS_NO, SYS_STR);
        return;
    }

    sprintf(IpAddr, "%d.%d.%d.%d", TCP2_IP1(D_K,P_K,0), TCP2_IP2(D_K,P_K,0), TCP2_IP3(D_K,P_K,0), TCP2_IP4(D_K,P_K,0));

    Log(USR_OK, "connecting to %s:%d", IpAddr, TCP2_PORT_NO);

    rt = Connect(SockTcpfd, IpAddr, TCP2_PORT_NO);
    if (rt < 0) {
        Log(TCP_ERROR, "connect fail {%d:%s}", SYS_NO, SYS_STR);
        close(SockTcpfd);
        SockTcpfd = -1;
        sleep(3);
        return;
    }

    OpenFlag = LogOnFlag = ON;

    return;
} /* End of Device_Open() */

/*------------------------------------------------------------------------
 *  Device_Close: TCP 연결 종료
 *  - 소켓 닫기 → 상태 플래그 초기화
 *------------------------------------------------------------------------*/
void Device_Close(void) {
    close(SockTcpfd);
    SockTcpfd = -1;
    sleep(3);
    Log(TCP_OK, "TCP device close");

    LogOnFlag = OFF;
    TCP2_LINE_ST = OpenFlag = OFF;

    return;
} /* End of Device_Close() */

/*------------------------------------------------------------------------
 *  Device_Write: TCP 데이터 전송
 *  - SendPkt 버퍼의 내용을 TCP로 전송
 *  - 전송 실패 시 Device_Close()
 *------------------------------------------------------------------------*/
void Device_Write(void) {
    int rt;

    rt = Select_Send(SockTcpfd, SendPkt, strlen(SendPkt));

    if (rt != OK) {
        Log(TCP_ERROR, "TCP data send fail");
        Device_Close();
    }

    INT_SEQ++;
    Log(TCP_OK, "TCP SD[%s] (%d)<%d>", SendPkt, strlen(SendPkt), INT_SEQ);

    return;
} /* End of Device_Write() */

/*------------------------------------------------------------------------
 *  main: 프로세스 초기화 → 시세수신 루프 → 종료
 *------------------------------------------------------------------------*/
int main(int argc, char *argv[]) {
    Init_Proc(argc, argv);
    PB_7100_UR();
    Exit_Process();
} /* End of main () */

/*------------------------------------------------------------------------
 *  PB_7100_UR: 메인 이벤트 루프
 *    1) 초기화 (Init_Parameters, Socket_Connect, Device_Open)
 *    2) UDP 데이터 수신 (Recv_Data)
 *    3) TR코드 분류:
 *       - A3/G7/B6/M4 → TCP 서버로 재전송 (시세 데이터)
 *       - 기타 → "0011LK000000000" 응답 전송 (heartbeat 등)
 *------------------------------------------------------------------------*/
void PB_7100_UR(void) {
    char    m_time[24];
    char    Wdt[30], W2_Fmt[512];
    char    rbuf[READ_BUF_SIZE];
    int     tr_gbn, rt, len, skip_rt, rbuf_len;

    BUFF_RW_HEAD        f_head;
    FILE_BUFF_FORMAT    W_Fmt;

    rt = Init_Parameters();
    if (rt == NOTOK)
        return;

    rt = Socket_Connect();
    if (rt == NOTOK)
        return;

    /* TCP 서버 초기 연결 */
    if (SockTcpfd < 0)
        Device_Open();

    while (START_S != JOB_END) {
        /* TCP 끊어졌으면 재연결 시도 */
        if (SockTcpfd < 0)
            Device_Open();
        if (SockTcpfd < 0)
            continue;   /* 연결 실패 → 재시도 */

        /* UDP 데이터 수신 */
        rt = Recv_Data(rbuf);
        if (rt == 0) {
            Log(USR_OK, "poll timeout");
            continue;
        }
        else if (rt < 0) {
            Log(UDP_ERROR, "receive fail {%d:%s}", SYS_NO, SYS_STR);
            close(Sockfd);

            /* UDP 소켓 재생성 */
            rt = Socket_Connect();
            if (rt == NOTOK)
                return;

            continue;
        }

        rbuf[rt] = '\0';
        rbuf_len = rt;

        /* TR코드 추출 (앞 2바이트) */
        memcpy(TrCode, rbuf, 2);
        TrCode[2] = '\0';

        /*------------------------------------------------------------
         *  TR코드별 처리 분기
         *  - A3(체결)/G7(호가)/B6(우선호가)/M4(장운영) → TCP 전달
         *  - 기타(heartbeat 등) → "0011LK000000000" 응답
         *------------------------------------------------------------*/
        if ((memcmp(TrCode, "A3", 2) == 0) ||
                (memcmp(TrCode, "G7", 2) == 0) ||
                (memcmp(TrCode, "B6", 2) == 0) ||
                (memcmp(TrCode, "M4", 2) == 0) ) {
            /* 시세 데이터 → TCP 서버로 전송 */
            rt = Select_Send(SockTcpfd, rbuf, rbuf_len);
            if (rt != OK) {
                Log(TCP_ERROR, "TCP data send fail");
                Device_Close();
            }

            INT_SEQ++;
            Log(TCP_OK, "TCP SD[%s] (%d)<%d>", rbuf, rbuf_len, INT_SEQ);
        }
        else {
            /* 기타 데이터 → LK 응답 (heartbeat 역할) */
            memcpy(rbuf, "0011", 4);            /* 길이 헤더 (4바이트) */
            memcpy(&rbuf[4], "LK000000000", 11);    /* LK 응답 코드 */
            rbuf[15] = '\0';

            rbuf_len = 15;
            rt = Select_Send(SockTcpfd, rbuf, rbuf_len);
            if (rt != OK) {
                Log(TCP_ERROR, "TCP data send fail");
                Device_Close();
            }

            INT_SEQ++;
            Log(TCP_OK, "TCP SD[%s] (%d)<%d>", rbuf, rbuf_len, INT_SEQ);
        }
    }

    return;
} /* End of PB_7100_UR () */

/*------------------------------------------------------------------------
 *  Init_Parameters: 프로세스 파라미터 초기화
 *  - ApType 문자열 생성
 *  - TCP 연결 정보 설정 (IP, 포트)
 *  - 상태 플래그 초기화
 *------------------------------------------------------------------------*/
int     Init_Parameters() {
    int     i, j, rt, flag;
    char    item_code[20], memberitem[10], tmp[128];
    char    d_time[16], head_size[10], cli_orsnd[21];
    char    fifo_name[100], bumun[4], m_time[24];

    /* ApType: 실행파일명에서 모듈+번호+타입 추출 (예: "PB7100UR") */
    sprintf(ApType, "%.2s%.4s%.2s", _Exe_Name, _Exe_Name+3, _Exe_Name+8);
    LtoU(ApType, strlen(ApType));

    /* 누적체결수량 초기화 */
    tot_cq = 0;
    LogOnFlag = OFF;
    OpenFlag = OFF;

    /* TCP2 설정에서 IP 주소 가져오기 */
    sprintf(IpAddr, "%d.%d.%d.%d", TCP2_IP1(D_K,P_K,0), TCP2_IP2(D_K,P_K,0), TCP2_IP3(D_K,P_K,0), TCP2_IP4(D_K,P_K,0));

    PortNo = TCP2_PORT_NO;
    Log(TCP_OK, "Server Side port[%d]", PortNo);

    TCP2_PROC_ST = ON;      /* 프로세스 상태: 기동 */
    TCP2_LINE_ST = OFF;     /* 회선 상태: 미연결 */

    return (OK);
} /* End of Init_Parameters () */

/*------------------------------------------------------------------------
 *  Socket_Connect: UDP 멀티캐스트 소켓 생성 및 그룹 Join
 *
 *  처리 순서:
 *    1) UDP 소켓 생성 (SOCK_DGRAM)
 *    2) NIC 인터페이스 결정 (개발: ens7f3, 운영: ens6f3)
 *    3) SO_REUSEADDR 설정
 *    4) bind() - 멀티캐스트 주소에 바인드
 *    5) ioctl로 NIC의 IP 주소 가져오기
 *    6) IP_ADD_MEMBERSHIP으로 멀티캐스트 그룹 Join
 *------------------------------------------------------------------------*/
int     Socket_Connect(void) {
    int     rt, val, len;
    char    ip_addr [16];
    char    ifnm [IFNAMSIZ] = {0};  /* 네트워크 인터페이스 이름 */

    /* UDP 설정에서 멀티캐스트 IP 주소 가져오기 */
    sprintf(ip_addr, "%d.%d.%d.%d", UDP_IP1(D_K,P_K,0), UDP_IP2(D_K,P_K,0),
            UDP_IP3(D_K,P_K,0), UDP_IP4(D_K,P_K,0));

    /* 서버 주소 설정 */
    bzero((unsigned char *)&SvrAddr, sizeof (SvrAddr));
    SvrAddr.sin_family          = AF_INET;
    inet_pton(AF_INET, ip_addr, &SvrAddr.sin_addr.s_addr);
    SvrAddr.sin_port            = htons(SVR_PORT_NO);

    /* 멀티캐스트 요청 구조체 설정 */
    bzero((unsigned char *)&mreq, sizeof (mreq));
    mreq.imr_multiaddr          = SvrAddr.sin_addr;
    mreq.imr_interface.s_addr   = htonl(INADDR_ANY);

    /* UDP 소켓 생성 */
    Sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (Sockfd < 0) {
        Log(UDP_FATAL, "socket open fail(%d:%s)", SYS_NO, SYS_STR);
        return (NOTOK);
    }

    /* NIC 인터페이스 결정: 192/10 대역 NIC 자동 탐색 */
    {
        if (find_ifname_by_192(ifnm) != 0) {
            Log(UDP_FATAL, "cannot find network interface for multicast");
            close(Sockfd);
            return (NOTOK);
        }

        Log(USR_OK, "interface name > [%s]", ifnm);
    }

    /* 2011.03 시세수신 증속에 따른 버퍼량 증가 */
    val = UDP_SOCK_RCVBUF_SIZE;
    len = sizeof(val);

    /* SO_REUSEADDR: 동일 포트 재사용 허용 */
    rt = setsockopt(Sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&val, len);

    if (rt == -1) {
        Log(UDP_WARN, "setsockopt(SO_RCVBUF) fail(%d:%s)", SYS_NO, SYS_STR);
        return (NOTOK);
    }

    /* 멀티캐스트 주소에 바인드 */
    if (bind(Sockfd, (struct sockaddr *) &SvrAddr, sizeof (SvrAddr)) < 0) {
        Log(UDP_FATAL, "bind fail(%d:%s)", SYS_NO, SYS_STR);
        return (NOTOK);
    }

    /* NIC의 실제 IP 주소를 가져와서 멀티캐스트 인터페이스로 설정 */
    {

        int     ii;
        struct ifreq ifreq;

        memset(&ifreq, 0, sizeof(ifreq));
        strncpy(ifreq.ifr_name, ifnm, IFNAMSIZ - 1);

        /* ioctl로 NIC에 할당된 IP 주소 가져오기 */
        if (ioctl(Sockfd, SIOCGIFADDR, &ifreq) < 0) {
            close(Sockfd);
            Log(UDP_FATAL, "ioctl(SIOCGIFADDR) fail");
            return (NOTOK);
        }

        /* 멀티캐스트 인터페이스를 NIC의 IP로 설정 */
        memcpy(&mreq.imr_interface, &((struct sockaddr_in *)&ifreq.ifr_addr)->sin_addr, sizeof(struct in_addr));

        /* 멀티캐스트 그룹 Join */
        rt = setsockopt(Sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof (mreq));
        if (rt == -1) {
            Log(UDP_WARN, "setsockopt MULTICAST fail(%d:%s)", SYS_NO, SYS_STR);
            return (NOTOK);
        }

    }

    Log(USR_OK, "socket connected:port[%s] [%d]", ip_addr, SVR_PORT_NO);
    return (OK);
} /* End of Socket_Connect () */

/*------------------------------------------------------------------------
 *  Recv_Data: UDP 데이터 수신
 *  - select()로 70초 타임아웃 대기
 *  - 데이터 도착 시 recvfrom()으로 수신
 *
 *  반환값:
 *    >0 : 수신 바이트 수
 *     0 : 타임아웃
 *    -1 : 에러
 *------------------------------------------------------------------------*/
int Recv_Data(char *p_str) {
    int rt, len;
    fd_set read_set;
    struct timeval timeout;

    len = sizeof (ClntAddr);

    FD_ZERO(&read_set);
    FD_SET(Sockfd, &read_set);
    timeout.tv_sec = 70;    /* 70초 타임아웃 */
    timeout.tv_usec = 0;

    rt = select(Sockfd + 1, &read_set, NULL, NULL, &timeout);
    if (rt < 0) {
        Log(SYS_FATAL, "select fail(%d:%s)", SYS_NO, SYS_STR);
        return (NOTOK);
    }
    if (rt == 0) return 0;  /* 타임아웃 */

        if (FD_ISSET(Sockfd, &read_set)) {
        rt = recvfrom(Sockfd, p_str, READ_BUF_SIZE, 0, (struct sockaddr *) &ClntAddr, (socklen_t *)&len);
        return(rt);
    }
    return (OK);
} /* End of Recv_Data () */

/*------------------------------------------------------------------------
 *  Add_Count_UR: TR코드별 UDP 수신 건수 카운트
 *  - sisetr.ini에 정의된 TR코드와 비교
 *  - 매칭되면 ur_count 증가
 *
 *  반환값:
 *    >0 : 데이터 길이 (해당 TR의 length)
 *     0 : queue가 0인 TR (수신만 카운트, 분배 안 함)
 *    -1 : 매칭 TR 없음
 *------------------------------------------------------------------------*/
int Add_Count_UR(void) {
    int rt = NOTOK;
    int T_K = NOTOK;
    int i;

    for (i = 0; i < DAEMON(D_K).sisetr_count; i++) {
        if (SISETR(D_K, i).tr[0] == '\0')
            break;  /* TR 목록 끝 */

        if (memcmp(SISETR(D_K, i).tr, TrCode, 5) == 0) {
            if (SISETR(D_K, i).queue == 0) {
                rt = 0;     /* 분배 안 하는 TR */
                break;
            }
            else {
                SISETR(D_K, i).ur_count++; /* 수신 건수 증가 */

                T_K = i;
                rt = SISETR(D_K, T_K).length;
                break;
            }
        }
    }
    return (rt);
} /* End of Add_Count_UR () */

/*------------------------------------------------------------------------
 *  Add_Count_DD: TR코드별 분배(DD) 건수 카운트
 *  - sisetr.ini에 정의된 TR코드와 비교
 *  - 매칭되면 dd_count 증가
 *
 *  반환값:
 *    >0 : 데이터 길이
 *    -1 : 매칭 TR 없음
 *------------------------------------------------------------------------*/
int Add_Count_DD(char *ptr) {
    int rt = NOTOK;
    int i;

    for (i = 0; i < DAEMON(D_K).sisetr_count; i++) {
        if (SISETR(D_K, i).tr[0] == '\0')
            break;

        if (memcmp(SISETR(D_K, i).tr, ptr, strlen(ptr)) == 0) {
            SISETR(D_K, i).dd_count++; /* 분배 건수 증가 */

            rt = SISETR(D_K, i).length;
            break;
        }
    }
    return (rt);
} /* End of Add_Count_DD () */

/*------------------------------------------------------------------------
 *  find_ifname_by_192: 192.x.x.x 또는 10.x.x.x 대역 NIC 찾기
 *  - 우선순위: 192.x.x.x > 10.x.x.x
 *  - getifaddrs()로 전체 인터페이스 탐색
 *
 *  반환값:
 *     0 : 성공 (ifnm에 인터페이스명 저장)
 *    -1 : 실패
 *------------------------------------------------------------------------*/
int find_ifname_by_192(char *ifnm) {
    struct ifaddrs *ifaddr, *ifa;
    char candidate10 [IFNAMSIZ] = {0};  /* 10.x.x.x 후보 */

    if (getifaddrs(&ifaddr) == -1)
        return -1;

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr)
            continue;

        if (ifa->ifa_addr->sa_family != AF_INET)
            continue;

        struct sockaddr_in *sa = (struct sockaddr_in *)ifa->ifa_addr;
        unsigned int ip = ntohl(sa->sin_addr.s_addr);

        /* 192.x.x.x (0xC0000000) → 최우선 */
        if ((ip & 0xFF000000) == 0xC0000000) {
            strncpy(ifnm, ifa->ifa_name, IFNAMSIZ - 1);
            ifnm[IFNAMSIZ - 1] = '\0';
            freeifaddrs(ifaddr);
            return 0;
        }
        /* 10.x.x.x (0x0A000000) → 후보 저장 */
        if ((ip & 0xFF000000) == 0x0A000000) {
            strncpy(candidate10, ifa->ifa_name, sizeof(candidate10) - 1);
            candidate10[sizeof(candidate10) - 1] = '\0';
        }
    }

    /* 192 대역 없으면 10 대역 사용 */
    if (candidate10[0] != '\0') {
        strncpy(ifnm, candidate10, IFNAMSIZ - 1);
        ifnm[IFNAMSIZ - 1] = '\0';
        freeifaddrs(ifaddr);
        return 0;
    }

    freeifaddrs(ifaddr);
    return -1;
}

/*------------------------------------------------------------------------
 *  End of program (pb_7100_ur.c)
 *------------------------------------------------------------------------*/
