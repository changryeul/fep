##########################################################################
#	Module	: make shell - library
#	File	: Make_Lib_P_c.sh
##########################################################################

case $osname in
	HP-UX)
		DEF_TMP="-Ae +DAportable -D_PSTAT64";	export DEF_TMP
		SLEEP_TMP="sleep 0";					export SLEEP_TMP;;
	SunOS)
		DEF_TMP="-lnsl -lsocket";				export DEF_TMP
		SLEEP_TMP="sleep 1";					export SLEEP_TMP;;
	AIX)
		DEF_TMP="-O -lnsl -lsocket -qcpluscmt";	export DEF_TMP
		SLEEP_TMP="sleep 0";					export SLEEP_TMP;;
	Linux)
		#DEF_TMP="-O -lnsl -lsocket";			export DEF_TMP
		DEF_TMP="-O -ltirpc -lsocket";			export DEF_TMP
		SLEEP_TMP="sleep 0";					export SLEEP_TMP;;
esac

cd $_P_SUB
LIB_TMP=libfepP.a;	export LIB_TMP

for i in *.c
do
	if [ $i = "dbipc.c" ]
	then
		continue
	fi

	echo ${i}
	SRC_TMP=${i};	export SRC_TMP
	make -f ${_PSUB_MAKE}/Make_Lib_P_c.mk
done

##########################################################################
#	End of File (Make_Lib_P_c.sh)
##########################################################################
